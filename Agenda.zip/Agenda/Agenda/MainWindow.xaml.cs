﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Agenda
{
    /// <summary>
    /// Interação lógica para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        string conexao = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|Agenda.mdf;Integrated Security=True";
        bool novo;

        private void btNovo_Click(object sender, RoutedEventArgs e)
        {
            txtBusca.Text = "";
            txtNomeEvento.Text = "";
            txtLocal.Text = "";
            txtNote.Text = "";
            txtHora.Text = "";
            dpData.Text = "";
            txtNomeEvento.IsEnabled = true;
            txtLocal.IsEnabled = true;
            txtNote.IsEnabled = true;
            txtHora.IsEnabled = true;
            dpData.IsEnabled = true;
            txtBusca.IsEnabled = true;
            btCancelar.IsEnabled = true;
            btSalvar.IsEnabled = true;
            novo = true;
        }

        private void btSalvar_Click(object sender, RoutedEventArgs e)
        {
            if (novo)
            {
                string sql = "insert into agendaPessoal (Evento,Data,Hora,Local,Note) values ('" + txtNomeEvento.Text + "','" + dpData.Text + "','"+ txtHora.Text +"',' " + txtLocal.Text + "','" + txtNote.Text + "')";
                SqlConnection con = new SqlConnection(conexao);
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.Text;
                con.Open();
                try
                {
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        MessageBox.Show("Evento " + txtNomeEvento.Text + " adicionado com sucesso");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.ToString());
                }
                finally
                {
                    con.Close();
                }

            }
            else
            {
                string sql = "update agendaPessoal set evento='"+txtNomeEvento.Text+"',data='"+dpData.Text+"" +
                    "',hora='"+txtHora.Text+"',local='"+txtLocal.Text+"" +
                    "',note='"+txtNote.Text+"'";
                SqlConnection con = new SqlConnection(conexao);
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.CommandType = CommandType.Text;
                con.Open();
                try
                {
                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        MessageBox.Show("Evento " + txtNomeEvento.Text + " atualizado com sucesso");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
            
            txtBusca.IsEnabled = true;
            btBuscar.IsEnabled = true;
            btNovo.IsEnabled = true;
            btExcluir.IsEnabled = false;
            btSalvar.IsEnabled = false;
            btCancelar.IsEnabled = false;
            txtNomeEvento.IsEnabled = false;
            txtLocal.IsEnabled = false;
            txtHora.IsEnabled = false;
            txtNote.IsEnabled = false;
            dpData.IsEnabled = false;

            
        }

        private void btExcluir_Click(object sender, RoutedEventArgs e)
        {
            string sql = "Delete from agendaPessoal where id=" + txtBusca.Text;
            SqlConnection con = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            con.Open();
            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Evento " + txtNomeEvento.Text + " excluido");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
            }

            txtBusca.Text = "";
            txtNomeEvento.Text = "";
            txtLocal.Text = "";
            txtNote.Text = "";
            txtHora.Text = "";
            dpData.Text = "";
            txtBusca.IsEnabled = false;
            txtNomeEvento.IsEnabled = false;
            txtLocal.IsEnabled = false;
            txtNote.IsEnabled = false;
            txtHora.IsEnabled = false;
            dpData.IsEnabled = false;
            txtBusca.IsEnabled = true;
            btBuscar.IsEnabled = true;
            btSalvar.IsEnabled = false;
            btNovo.IsEnabled = true;
            btCancelar.IsEnabled = false;
            btExcluir.IsEnabled = false;

        }

        private void btCancelar_Click(object sender, RoutedEventArgs e)
        {
            txtBusca.Text = "";
            txtNomeEvento.Text = "";
            txtLocal.Text = "";
            txtNote.Text = "";
            txtHora.Text = "";
            dpData.Text = "";
            txtBusca.IsEnabled = true;
        }

        private void Buscar_Click(object sender, RoutedEventArgs e)
        {
            string sql = "Select * from agendaPessoal where id= " + txtBusca.Text ;
            SqlConnection con = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            con.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    btNovo.IsEnabled = true;
                    btSalvar.IsEnabled = false;
                    btCancelar.IsEnabled = false;
                    btExcluir.IsEnabled = true;
                    btBuscar.IsEnabled = false;
                    txtBusca.IsEnabled = false;
                    txtNomeEvento.IsEnabled = true;
                    txtLocal.IsEnabled = true;
                    txtNote.IsEnabled = true;
                    txtHora.IsEnabled = true;
                    dpData.IsEnabled = true;
                    novo = false;
                    txtNomeEvento.Focus();
                    txtBusca.Text = reader[0].ToString();
                    txtNomeEvento.Text = reader[1].ToString();
                    dpData.Text = reader[2].ToString();
                    txtHora.Text = reader[3].ToString();
                    txtLocal.Text = reader[4].ToString();
                    txtNote.Text = reader[5].ToString();
                }
                else
                {
                    MessageBox.Show("Nenhum registro encontrado com o ID informado");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                con.Close();
            }
            txtBusca.IsEnabled = true;
            btSalvar.IsEnabled = true;
            btExcluir.IsEnabled = true;
            btCancelar.IsEnabled = false;
            btBuscar.IsEnabled = true;
            btNovo.IsEnabled = true;
        }

    }
}
